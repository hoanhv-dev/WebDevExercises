export enum RoutePath {
  Root = '',
  Auth = 'auth',
  Login = 'login',
  Register = 'register',
  Home = 'home',
}
