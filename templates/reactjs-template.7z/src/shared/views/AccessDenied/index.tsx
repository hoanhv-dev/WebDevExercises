const AccessDenied = () => <>No permission to load this page!</>;

export default AccessDenied;
