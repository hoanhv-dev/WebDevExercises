const NoMatch = () => <>404!</>;

export default NoMatch;
