import { Suspense } from 'react';
import { Outlet } from 'react-router-dom';

const PrivateLayout = () => (
  <Suspense fallback={<></>}>
    <nav>Header</nav>
    <Outlet />
    <div>Footer</div>
  </Suspense>
);

export default PrivateLayout;
