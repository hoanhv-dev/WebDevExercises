export type Loader = {
  isLoading: boolean;
  isError: boolean;
  counter: number;
};
