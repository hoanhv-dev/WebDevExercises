export default {
  parser: 'postcss',
  plugins: {
    '@tailwindcss/postcss': {},
  },
}
